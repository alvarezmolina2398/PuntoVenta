﻿$(function () {

});



function encaMenu() {


}

function detaMenu() {

}