﻿Imports System.Data
Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols

' Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente.
<System.Web.Script.Services.ScriptService()>
<WebService(Namespace:="http://tempuri.org/")>
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Public Class wsvalidaciones
    Inherits System.Web.Services.WebService

    <WebMethod()>
    Public Function validarLimiteCredito(ByVal usuario As String, ByVal cliente As Integer, ByVal valor As Double) As Boolean
        Dim result As Boolean = False


        Dim existevalidacion As String = "SELECT limite_credito_cliente FROM Config_empresa where id_empresa = (Select id_empresa from USUARIO where USUARIO = '" & usuario & "')"


        Dim existeValidacionResult As Integer = 0
        Dim TablaEncabezado As DataTable = manipular.ObtenerDatos(existevalidacion)

        For i = 0 To TablaEncabezado.Rows.Count - 1

            existeValidacionResult = TablaEncabezado.Rows(i).Item("limite_credito_cliente")
        Next



        If existeValidacionResult = 0 Then
            result = True
        Else

            Dim clientelimitesql As String = "select Limite_Credito  from CLiente where Id_Clt = " & cliente & ";"


            Dim limite As Integer = 0
            Dim TablaEncabezado2 As DataTable = manipular.ObtenerDatos(clientelimitesql)

            For i = 0 To TablaEncabezado2.Rows.Count - 1

                limite = TablaEncabezado2.Rows(i).Item("Limite_Credito")
            Next


            If limite = 0 Then
                result = False
            Else
                Dim credito As Double
                Dim valoralcanzado As String = "SELECT  valor - recibos saldos FROM (  " &
                    "SELECT  SUM(df.Sub_Total) valor, ISNULL((SELECT SUM(abonado) FROM DET_RECIBO_FACT WHERE id_enc = ef.id_enc), 0) recibos  " &
                    "FROM ENC_FACTURA ef   " &
                    "INNER JOIN DET_FACTURA df on ef.id_enc = df.id_enc    " &
                    "INNER JOIN CLiente c on ef.Id_Clt = c.Id_Clt   " &
                    " WHERE c.Id_Clt =  2 and ef.estado = 1  " &
                    " group by ef.id_enc " &
                    ") fac WHERE valor > recibos;"


                Dim TablaEncabezado3 As DataTable = manipular.ObtenerDatos(valoralcanzado)

                For i = 0 To TablaEncabezado3.Rows.Count - 1

                    credito += TablaEncabezado3.Rows(i).Item("saldos")
                Next



                Dim comanda As String = "SELECT Total_factura FROM  [ENCA_RESERVA] WHERE estado = 1 and id_Ctl =  " & cliente

                Dim comandaval As Double = 0
                Dim TablaEncabezado4 As DataTable = manipular.ObtenerDatos(comanda)

                For i = 0 To TablaEncabezado4.Rows.Count - 1

                    comandaval += TablaEncabezado4.Rows(i).Item("Total_factura")
                Next


                credito = credito + valor + comandaval



                If credito > limite Then
                    result = False
                Else
                    result = True
                End If

            End If
        End If

        Return result
    End Function



    <WebMethod()>
    Public Function validarDocumentosCredito(ByVal usuario As String, ByVal cliente As Integer) As Boolean
        Dim result As Boolean = False


        Dim existevalidacion As String = "SELECT bloqueo_documentos FROM Config_empresa where id_empresa = (Select id_empresa from USUARIO where USUARIO = '" & usuario & "')"


        Dim existeValidacionResult As Integer = 0
        Dim TablaEncabezado As DataTable = manipular.ObtenerDatos(existevalidacion)

        For i = 0 To TablaEncabezado.Rows.Count - 1

            existeValidacionResult = TablaEncabezado.Rows(i).Item("bloqueo_documentos")
        Next



        If existeValidacionResult = 0 Then
            result = True
        Else

            Dim clientelimitesql As String = "select Limite_Credito  from CLiente where Id_Clt = " & cliente & ";"


            Dim limite As Integer = 0
            Dim TablaEncabezado2 As DataTable = manipular.ObtenerDatos(clientelimitesql)

            For i = 0 To TablaEncabezado2.Rows.Count - 1

                limite = TablaEncabezado2.Rows(i).Item("Limite_Credito")
            Next


            If limite = 0 Then
                result = False
            Else
                Dim dias As Double
                Dim valoralcanzado As String = "SELECT  count(Fecha) as dias FROM ( " &
                "SELECT DATEDIFF(day,Getdate(),DATEADD(day,(select c.Dias_Credito from CLiente c where c.Id_Clt = " & cliente & "),ef.Fecha)) Fecha, SUM(df.Sub_Total) valor, ISNULL((SELECT SUM(abonado) FROM DET_RECIBO_FACT WHERE id_enc = ef.id_enc), 0) recibos " &
                "FROM ENC_FACTURA ef " &
                "INNER JOIN DET_FACTURA df on ef.id_enc = df.id_enc  " &
                "INNER JOIN CLiente c on ef.Id_Clt = c.Id_Clt " &
                " WHERE c.Id_Clt =  " & cliente & " and ef.estado = 1 " &
                " group by ef.id_enc, Fecha " &
                ")fac WHERE valor > recibos and Fecha < 0;"


                Dim TablaEncabezado3 As DataTable = manipular.ObtenerDatos(valoralcanzado)

                For i = 0 To TablaEncabezado3.Rows.Count - 1

                    dias = TablaEncabezado3.Rows(i).Item("dias")
                Next

                If dias > 0 Then
                    result = False
                Else
                    result = True
                End If

            End If
        End If

        Return result
    End Function



    <WebMethod()>
    Public Function ValidarFechaVEncimiento(ByVal serie As String, ByVal numero As String) As Boolean
        Dim result As Boolean = False


        Dim existevalidacion As String = "SELECT isnull(count(*),0) as cantidad FROM ENC_RECIBO where serie = '" & serie & "' and numero = '" & numero & "'"


        Dim existeValidacionResult As Integer = 0
        Dim TablaEncabezado As DataTable = manipular.ObtenerDatos(existevalidacion)

        existeValidacionResult = TablaEncabezado.Rows(0).Item("cantidad")



        If existeValidacionResult = 0 Then
            result = True
        Else
            result = False
        End If
        Return result
    End Function

    <WebMethod()>
    Public Function validarResolucion(ByVal resolucion As String, ByVal id As Integer) As Boolean
        Dim result As Boolean = False

        Dim existevalidacion As String = ""
        If Not id = 0 Then
            existevalidacion = "Select isnull(count(*), 0) cantidad FROM Correlativos where Autorizacion = '" & resolucion & "' and id_correlativo <> " & id
        Else
            existevalidacion = "Select isnull(count(*), 0) cantidad FROM Correlativos where Autorizacion = '" & resolucion & "' "
        End If




        Dim existeValidacionResult As Integer = 0
        Dim TablaEncabezado As DataTable = manipular.ObtenerDatos(existevalidacion)

        existeValidacionResult = TablaEncabezado.Rows(0).Item("cantidad")



        If existeValidacionResult = 0 Then
            result = True
        Else
            result = False
        End If
        Return result
    End Function


    <WebMethod()>
    Public Function validarSerie(ByVal serie As String, ByVal id As Integer, ByVal company As Integer, ByVal del As Integer, ByVal al As Integer) As Boolean
        Dim result As Boolean = False

        Dim existevalidacion As String = ""
        If Not id = 0 Then
            existevalidacion = "Select isnull(count(*), 0) cantidad FROM Correlativos where Series = '" & serie & "' and id_empresa = " & company & " and (Fact_inic = " & del & " and Fact_fin = " & al & ") and id_correlativo <> " & id
        Else
            existevalidacion = "Select isnull(count(*), 0) cantidad FROM Correlativos where Series = '" & serie & "' and (Fact_inic = " & del & " and Fact_fin = " & al & ") and id_empresa =  " & company
        End If




        Dim existeValidacionResult As Integer = 0
        Dim TablaEncabezado As DataTable = manipular.ObtenerDatos(existevalidacion)

        existeValidacionResult = TablaEncabezado.Rows(0).Item("cantidad")

        If existeValidacionResult = 0 Then
            result = True
        Else
            result = False
        End If
        Return result
    End Function

    <WebMethod()>
    Public Function validarSerieFecha(ByVal serie As Integer) As Boolean
        Dim result As Boolean = False

        Dim existevalidacion As String = "SELECT case when fechavencimiento < cast(GETDATE() as date) then 0 ELSE 1 END as result  FROM Correlativos where id_correlativo = " & serie & ";"


        Dim existeValidacionResult As Integer = 0
        Dim TablaEncabezado As DataTable = manipular.ObtenerDatos(existevalidacion)

        existeValidacionResult = TablaEncabezado.Rows(0).Item("result")



        If existeValidacionResult = 0 Then
            result = False
        Else

            Dim sql2 As String = "SELECT case when Corr_Act = Fact_fin then 0 ELSE 1 END as result  FROM Correlativos where id_correlativo = " & serie & ";"

            Dim TablaEncabezado2 As DataTable = manipular.ObtenerDatos(sql2)

            Dim existeValidacionResult2 = TablaEncabezado2.Rows(0).Item("result")

            If existeValidacionResult2 = 0 Then
                result = False
            Else
                result = True
            End If

        End If
        Return result
    End Function

End Class


