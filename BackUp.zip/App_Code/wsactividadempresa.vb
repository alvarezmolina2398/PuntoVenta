﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Data

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class wsactividadempresa
    Inherits System.Web.Services.WebService
    'metod utilizado para mostrar el listado de los tipos de articulo 
    <WebMethod()> _
    Public Function ObtenerDatos() As List(Of Datos)

        'enviar tipo
        Dim result As List(Of [Datos]) = New List(Of Datos)()
        Dim StrEncabezado As String = "SELECT * FROM ACTIVIDADES_CIA WHERE estado = 1 "
        Dim TablaEncabezado As DataTable = manipular.Login(StrEncabezado)

        For i = 0 To TablaEncabezado.Rows.Count - 1
            For ii = 0 To 1
                Dim Elemento As New Datos
                Elemento.id = TablaEncabezado.Rows(i).Item("id_actividad")
                Elemento.nombre = TablaEncabezado.Rows(i).Item("descripcion").ToString
                result.Add(Elemento)
                ii = ii + 1
            Next
        Next

        Return result
    End Function

    'metodo utilizado para insertar un tipo
    <WebMethod()> _
    Public Function GuardarDatos(ByVal nombre As String) As Boolean
        Dim result As Boolean = False
        Dim id As String = Nothing
        id = manipular.idempresabusca("SELECT MAX(id_actividad) FROM ACTIVIDADES_CIA")
        Dim ide As Double = 0
        If id = "" Then
            ide = 1
        Else
            ide = Convert.ToDouble(id) + 1
        End If

        Dim StrEncabezado As String = "INSERT INTO ACTIVIDADES_CIA (id_actividad,descripcion,estado) VALUES (" & ide & ",'" & nombre & "',1)"
        result = manipular.EjecutaTransaccion1(StrEncabezado)
        Return result
    End Function

    'metodo utilizado para actualizar un tipo
    <WebMethod()> _
    Public Function ActualizarDatos(ByVal nombre As String, ByVal id As Integer) As Boolean
        Dim result As Boolean = False
        Dim StrEncabezado As String = "UPDATE ACTIVIDADES_CIA SET descripcion = '" & nombre & "' WHERE id_actividad=" & id
        result = manipular.EjecutaTransaccion1(StrEncabezado)
        Return result
    End Function

    'metodo utilizado para deshabilitar un tipo
    <WebMethod()> _
    Public Function Eliminar(ByVal id As Integer) As Boolean
        Dim result As Boolean = False
        Dim StrEncabezado As String = "UPDATE ACTIVIDADES_CIA SET estado=0 WHERE id_actividad=" & id
        result = manipular.EjecutaTransaccion1(StrEncabezado)
        Return result
    End Function

    Public Class Datos
        Public id As Integer
        Public nombre As String
    End Class
End Class